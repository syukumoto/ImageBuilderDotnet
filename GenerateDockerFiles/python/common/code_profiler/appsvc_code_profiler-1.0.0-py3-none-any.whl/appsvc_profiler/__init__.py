from .installer import *
from .main import *
from .constants import CodeProfilerConstants

__version__ = CodeProfilerConstants.APPSVC_PROFILER_VERSION

