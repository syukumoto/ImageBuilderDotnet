import string
import click
import logging
import os

from .constants import CodeProfilerConstants as constants
from .helpers import is_like_true
from pathlib import Path
from .profiler import CodeProfiler

def initialize_logger():
    logging.basicConfig(filename=constants.CODE_PROFILER_DEBUG_LOG_FILE,
                        filemode='a',
                        format='%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s',
                        datefmt="%Y_%m_%d_%H_%M_%S",
                        level=logging.DEBUG)
    return logging.getLogger()

logger = initialize_logger()
logger.setLevel= logging.DEBUG

def ensure_logs_dir_is_created():
    try:
        Path(constants.CODE_PROFILER_LOGS_DIR).mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.exception(e)

@click.command()
@click.option("--attach", "-a", help="PID of the gunicorn worker process to profile", required=True,type=int)
@click.option("--time-to-profile", "-t", help="Number of seconds to profiler", type=int, default=0)
@click.option("--output-filename", "-o", help="Output Filename", type=str,default="")
def main(attach, time_to_profile, output_filename):
    code_profiler_enabled_app_setting_value = os.getenv(constants.APP_SETTING_TO_ENABLE_CODE_PROFILER, None)
    signal_handlers_not_initialized_app_setting_value = os.getenv(constants.CODE_PROFILER_SIGNAL_HANDLER_NOT_INITIALIZED_ENV_NAME, None)    
    code_profiler_enabled = code_profiler_enabled_app_setting_value is None or is_like_true(code_profiler_enabled_app_setting_value)
    signal_handlers_not_initialized = code_profiler_enabled_app_setting_value is None or is_like_true(signal_handlers_not_initialized_app_setting_value)    
    
    logger.debug(f"{constants.APP_SETTING_TO_ENABLE_CODE_PROFILER} : {code_profiler_enabled_app_setting_value}")
    logger.debug(f"{constants.CODE_PROFILER_SIGNAL_HANDLER_NOT_INITIALIZED_ENV_NAME} : {signal_handlers_not_initialized_app_setting_value}")
    
    if not code_profiler_enabled:
        display("To enable code profiler, add the App Setting WEBSITE_ENABLE_DEFAULT_CODE_PROFILER=true")
        display("NOTE : Adding this App Setting will restart your App Service !!")
        display("")
    elif signal_handlers_not_initialized:
        display("There was an issue while installing code profiler.")
        display(f"Please review debug log in {constants.CODE_PROFILER_LOGS_DIR}")
    else:
        logger.info("Code Profiler is enabled and signal handlers are initialized")
        code_profiler = CodeProfiler(attach, time_to_profile)        
        try:
            code_profiler.profile()        
        except KeyboardInterrupt :
            pass
            
        code_profiler.save_traces(output_filename)
        code_profiler.show_step_to_review_traces()

# Rich library spinners are overlapping with logging console handlers.
# Hence using logger seperately and printing the statements manually
def display(message):
    print(message)    
    logger.info(message)
        
