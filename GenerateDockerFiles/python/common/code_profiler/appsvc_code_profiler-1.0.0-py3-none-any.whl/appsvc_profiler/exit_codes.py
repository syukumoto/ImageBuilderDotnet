class CodeProfilerExitCodes:
    Success=0    
    Limitation=1
    Disabled=2
    SignalHandlersNotInitialized=3 